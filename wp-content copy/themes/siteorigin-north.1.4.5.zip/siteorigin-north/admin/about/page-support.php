<h3><?php _e( 'Support and Documentation', 'siteorigin-north' ) ?></h3>
<p>
	<?php printf( __( "Our dedicated support team is ready to help you over on our %sfree support forums%s.", 'siteorigin-north' ), '<a href="https://siteorigin.com/thread/">', '</a>' ) ?>
</p>
