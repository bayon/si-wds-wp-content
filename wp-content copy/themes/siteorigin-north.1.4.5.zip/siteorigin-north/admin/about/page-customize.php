<h3><?php _e( 'Unlimited Customization', 'siteorigin-north' ) ?></h3>
<p>
	<?php printf( __( "North is easy to customize, right inside the %sWordPress Customizer%s.", 'siteorigin-north' ), '<a href="' . admin_url( 'customize.php' ) . '">', '</a>' ) ?>
	<?php printf( __( "If there's something else you need to customize, then try out our free %sSiteOrigin CSS%s plugin.", 'siteorigin-north' ), '<a href="https://wordpress.org/plugins/so-css/">', '</a>' ) ?>
</p>
