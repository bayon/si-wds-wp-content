<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 5674,
		"score": 180.75543551895922,
		"percent": 68.47682460273967
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 1037,
		"score": 74.94025549254974,
		"percent": 28.390132315050476
	},
	"0f7f79a15dafbc4c1b64dfdc79c6937d": {
		"name": "adiraomj",
		"email": "0f7f79a15dafbc4c1b64dfdc79c6937d",
		"loc": 346,
		"score": 5.009521564971669,
		"percent": 1.897791502442682
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 50,
		"score": 2.918653303332804,
		"percent": 1.1056935010264966
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 8,
		"score": 0.3252970702815668,
		"percent": 0.12323452604068162
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2,
		"score": 0.016692019949009755,
		"percent": 0.006323552699989943
	}
}', true );